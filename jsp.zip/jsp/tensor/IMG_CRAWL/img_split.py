import splitfolders
# pip install split-folders
splitfolders.ratio('./dataset'
                   , output='whale', seed=1, ratio=(.8,.0,.2))